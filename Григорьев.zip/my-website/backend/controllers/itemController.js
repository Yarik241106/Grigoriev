const Item = require('../models/Item');

function getAuthUserId(req) {
  const userId = req.user && req.user.userId;
  return userId;
}

async function getAll(req, res) {
  const { page, limit, search } = req.query || {};
  const result = await Item.getAll({ page, limit, search });
  return res.status(200).json(result);
}

async function getById(req, res) {
  const { id } = req.params;
  const result = await Item.getById(id);
  if (!result) return res.status(404).json({ message: 'Not found' });
  return res.status(200).json(result);
}

async function create(req, res) {
  const userId = getAuthUserId(req);
  if (!userId) return res.status(401).json({ message: 'Unauthorized' });

  const { title, content, tags } = req.body || {};
  if (!title || content == null) {
    return res.status(400).json({ message: 'title and content are required' });
  }

  const created = await Item.create({ title, content, tags, userId });
  if (!created) return res.status(500).json({ message: 'Server error' });
  return res.status(201).json(created);
}

async function update(req, res) {
  const userId = getAuthUserId(req);
  if (!userId) return res.status(401).json({ message: 'Unauthorized' });

  const { id } = req.params;
  const { title, content, tags } = req.body || {};

  const result = await Item.update(id, { title, content, tags }, userId);
  if (result && result.notFound) return res.status(404).json({ message: 'Not found' });
  if (result && result.forbidden) return res.status(403).json({ message: 'Forbidden' });
  return res.status(200).json(result.updated);
}

async function remove(req, res) {
  const userId = getAuthUserId(req);
  if (!userId) return res.status(401).json({ message: 'Unauthorized' });

  const { id } = req.params;
  const result = await Item.remove(id, userId);
  if (result && result.notFound) return res.status(404).json({ message: 'Not found' });
  if (result && result.forbidden) return res.status(403).json({ message: 'Forbidden' });
  return res.status(200).json({ message: 'Deleted' });
}

async function likeAdd(req, res) {
  const userId = getAuthUserId(req);
  if (!userId) return res.status(401).json({ message: 'Unauthorized' });

  const { id } = req.params;
  const result = await Item.likeAdd(id, userId);
  if (result && result.notFound) return res.status(404).json({ message: 'Not found' });
  return res.status(200).json(result);
}

async function likeRemove(req, res) {
  const userId = getAuthUserId(req);
  if (!userId) return res.status(401).json({ message: 'Unauthorized' });

  const { id } = req.params;
  const result = await Item.likeRemove(id, userId);
  if (result && result.notFound) return res.status(404).json({ message: 'Not found' });
  return res.status(200).json(result);
}

async function addComment(req, res) {
  const userId = getAuthUserId(req);
  if (!userId) return res.status(401).json({ message: 'Unauthorized' });

  const { id } = req.params;
  const { content } = req.body || {};
  if (!content) return res.status(400).json({ message: 'content is required' });

  const result = await Item.addComment(id, { content }, userId);
  if (result && result.notFound) return res.status(404).json({ message: 'Not found' });
  return res.status(201).json(result.comment);
}

async function updateComment(req, res) {
  const userId = getAuthUserId(req);
  if (!userId) return res.status(401).json({ message: 'Unauthorized' });

  const { id, cid } = req.params;
  const { content } = req.body || {};
  if (!content) return res.status(400).json({ message: 'content is required' });

  const result = await Item.updateComment(id, cid, { content }, userId);
  if (result && result.notFound) return res.status(404).json({ message: 'Not found' });
  if (result && result.forbidden) return res.status(403).json({ message: 'Forbidden' });
  return res.status(200).json(result.comment);
}

async function deleteComment(req, res) {
  const userId = getAuthUserId(req);
  if (!userId) return res.status(401).json({ message: 'Unauthorized' });

  const { id, cid } = req.params;
  const result = await Item.deleteComment(id, cid, userId);
  if (result && result.notFound) return res.status(404).json({ message: 'Not found' });
  if (result && result.forbidden) return res.status(403).json({ message: 'Forbidden' });
  return res.status(200).json({ message: 'Deleted' });
}

module.exports = {
  getAll,
  getById,
  create,
  update,
  remove,
  likeAdd,
  likeRemove,
  addComment,
  updateComment,
  deleteComment,
};

