const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

async function register(req, res) {
  const { username, email, password } = req.body || {};
  if (!username || !email || !password) {
    return res.status(400).json({ message: 'username, email and password are required' });
  }

  try {
    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.createUser({ username, email, passwordHash });
    return res.status(201).json({ id: user.id, username: user.username, email: user.email });
  } catch (e) {
    // Чаще всего уникальность email нарушена.
    if (String(e && e.code) === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'Email already in use' });
    }
    return res.status(500).json({ message: 'Server error' });
  }
}

async function login(req, res) {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ message: 'email and password are required' });
  }

  const user = await User.findByEmail(email);
  if (!user) return res.status(401).json({ message: 'Invalid credentials' });

  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ message: 'Invalid credentials' });

  const token = jwt.sign(
    { userId: user.id, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );

  return res.status(200).json({ token });
}

async function logout(_req, res) {
  // JWT stateless: без черного списка просто подтверждаем выход.
  return res.status(200).json({ message: 'Logged out' });
}

async function me(req, res) {
  const userId = req.user && req.user.userId;
  if (!userId) return res.status(401).json({ message: 'Unauthorized' });

  const user = await User.findById(userId);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });

  return res.status(200).json({ id: user.id, username: user.username, email: user.email, created_at: user.created_at });
}

module.exports = { register, login, logout, me };

