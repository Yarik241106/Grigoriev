const { pool } = require('./db');

function normalizeTags(tags) {
  if (tags == null) return null;
  if (Array.isArray(tags)) return JSON.stringify(tags);
  if (typeof tags === 'string') {
    // Если строка уже JSON — оставим как есть, иначе попробуем как массив.
    return tags;
  }
  return JSON.stringify(tags);
}

function parseMaybeJson(value) {
  if (value == null) return value;
  if (typeof value === 'string') {
    try {
      return JSON.parse(value);
    } catch {
      return value;
    }
  }
  return value;
}

async function getItemOwnerId(itemId) {
  const [rows] = await pool.execute('SELECT user_id FROM items WHERE id = ?', [itemId]);
  return rows[0] ? rows[0].user_id : null;
}

async function ensureItemExists(itemId) {
  const [rows] = await pool.execute('SELECT id FROM items WHERE id = ?', [itemId]);
  return !!rows[0];
}

async function getAll({ page, limit, search } = {}) {
  const pageNum = Math.max(parseInt(page, 10) || 1, 1);
  const limitNum = Math.min(Math.max(parseInt(limit, 10) || 10, 1), 50);
  const offset = (pageNum - 1) * limitNum;

  const likeParam = `%${search || ''}%`;
  const hasSearch = typeof search === 'string' && search.trim() !== '';

  let whereSql = '';
  let params = [];
  if (hasSearch) {
    whereSql = 'WHERE (items.title LIKE ? OR CAST(items.tags AS CHAR) LIKE ?)';
    params = [likeParam, likeParam];
  }

  const [countRows] = await pool.execute(`SELECT COUNT(*) AS total FROM items ${whereSql}`, params);
  const total = countRows[0] ? countRows[0].total : 0;
  const totalPages = limitNum > 0 ? Math.ceil(total / limitNum) : 1;

  const [rows] = await pool.execute(
    `SELECT
        items.id,
        items.title,
        items.content,
        items.tags,
        items.user_id,
        items.created_at,
        u.username AS author_username,
        COUNT(DISTINCT l.id) AS likes_count,
        COUNT(DISTINCT c.id) AS comments_count
      FROM items
      JOIN users u ON u.id = items.user_id
      LEFT JOIN likes l ON l.item_id = items.id
      LEFT JOIN comments c ON c.item_id = items.id
      ${whereSql}
      GROUP BY items.id
      ORDER BY items.created_at DESC
      LIMIT ? OFFSET ?`,
    [...params, limitNum, offset]
  );

  const data = rows.map((r) => ({
    id: r.id,
    title: r.title,
    content: r.content,
    tags: parseMaybeJson(r.tags),
    user_id: r.user_id,
    created_at: r.created_at,
    author_username: r.author_username,
    likes_count: r.likes_count ? Number(r.likes_count) : 0,
    comments_count: r.comments_count ? Number(r.comments_count) : 0,
  }));

  return { data, meta: { page: pageNum, limit: limitNum, total, totalPages } };
}

async function getById(itemId) {
  const [itemRows] = await pool.execute(
    `SELECT
        items.id,
        items.title,
        items.content,
        items.tags,
        items.user_id,
        items.created_at,
        u.username AS author_username,
        (SELECT COUNT(*) FROM likes WHERE likes.item_id = items.id) AS likes_count
      FROM items
      JOIN users u ON u.id = items.user_id
      WHERE items.id = ?`,
    [itemId]
  );

  const item = itemRows[0];
  if (!item) return null;

  const [commentRows] = await pool.execute(
    `SELECT
        comments.id,
        comments.content,
        comments.item_id,
        comments.user_id,
        comments.created_at,
        u.username AS author_username
      FROM comments
      JOIN users u ON u.id = comments.user_id
      WHERE comments.item_id = ?
      ORDER BY comments.created_at ASC`,
    [itemId]
  );

  return {
    item: {
      id: item.id,
      title: item.title,
      content: item.content,
      tags: parseMaybeJson(item.tags),
      user_id: item.user_id,
      created_at: item.created_at,
      author_username: item.author_username,
      likes_count: item.likes_count ? Number(item.likes_count) : 0,
      comments_count: commentRows.length,
    },
    comments: commentRows.map((c) => ({
      id: c.id,
      content: c.content,
      item_id: c.item_id,
      user_id: c.user_id,
      created_at: c.created_at,
      author_username: c.author_username,
    })),
  };
}

async function create({ title, content, tags, userId }) {
  const tagsJson = normalizeTags(tags);
  const [result] = await pool.execute(
    'INSERT INTO items (title, content, tags, user_id) VALUES (?, ?, ?, ?)',
    [title, content, tagsJson, userId]
  );
  const itemId = result.insertId;
  const created = await getById(itemId);
  return created ? created.item : null;
}

async function update(itemId, { title, content, tags }, userId) {
  const ownerId = await getItemOwnerId(itemId);
  if (ownerId === null) return { notFound: true };
  if (Number(ownerId) !== Number(userId)) return { forbidden: true };

  const tagsJson = tags === undefined ? undefined : normalizeTags(tags);
  const nextFields = {
    title,
    content,
    tags: tagsJson,
  };

  // Обновляем только те поля, которые пришли (кроме пустых).
  const sets = [];
  const params = [];
  if (nextFields.title !== undefined) {
    sets.push('title = ?');
    params.push(nextFields.title);
  }
  if (nextFields.content !== undefined) {
    sets.push('content = ?');
    params.push(nextFields.content);
  }
  if (nextFields.tags !== undefined) {
    sets.push('tags = ?');
    params.push(nextFields.tags);
  }

  if (sets.length === 0) return { updated: await getById(itemId) };

  params.push(itemId);
  await pool.execute(`UPDATE items SET ${sets.join(', ')} WHERE id = ?`, params);
  const updated = await getById(itemId);
  return { updated: updated ? updated.item : null };
}

async function remove(itemId, userId) {
  const ownerId = await getItemOwnerId(itemId);
  if (ownerId === null) return { notFound: true };
  if (Number(ownerId) !== Number(userId)) return { forbidden: true };

  await pool.execute('DELETE FROM items WHERE id = ?', [itemId]);
  return { deleted: true };
}

async function likeAdd(itemId, userId) {
  const exists = await ensureItemExists(itemId);
  if (!exists) return { notFound: true };

  await pool.execute(
    `INSERT INTO likes (item_id, user_id)
     VALUES (?, ?)
     ON DUPLICATE KEY UPDATE id = id`,
    [itemId, userId]
  );

  const [rows] = await pool.execute('SELECT COUNT(*) AS likes_count FROM likes WHERE item_id = ?', [itemId]);
  return { likes_count: rows[0] ? Number(rows[0].likes_count) : 0 };
}

async function likeRemove(itemId, userId) {
  const exists = await ensureItemExists(itemId);
  if (!exists) return { notFound: true };

  await pool.execute('DELETE FROM likes WHERE item_id = ? AND user_id = ?', [itemId, userId]);
  const [rows] = await pool.execute('SELECT COUNT(*) AS likes_count FROM likes WHERE item_id = ?', [itemId]);
  return { likes_count: rows[0] ? Number(rows[0].likes_count) : 0 };
}

async function addComment(itemId, { content }, userId) {
  const exists = await ensureItemExists(itemId);
  if (!exists) return { notFound: true };

  const [result] = await pool.execute(
    'INSERT INTO comments (content, item_id, user_id) VALUES (?, ?, ?)',
    [content, itemId, userId]
  );
  const commentId = result.insertId;

  const [rows] = await pool.execute(
    `SELECT
        comments.id,
        comments.content,
        comments.item_id,
        comments.user_id,
        comments.created_at,
        u.username AS author_username
      FROM comments
      JOIN users u ON u.id = comments.user_id
      WHERE comments.id = ?`,
    [commentId]
  );

  return { comment: rows[0] };
}

async function updateComment(itemId, commentId, { content }, userId) {
  const [rows] = await pool.execute(
    'SELECT user_id FROM comments WHERE id = ? AND item_id = ?',
    [commentId, itemId]
  );

  if (!rows[0]) return { notFound: true };
  if (Number(rows[0].user_id) !== Number(userId)) return { forbidden: true };

  await pool.execute('UPDATE comments SET content = ? WHERE id = ? AND item_id = ?', [
    content,
    commentId,
    itemId,
  ]);

  const [commentRows] = await pool.execute(
    `SELECT
        comments.id,
        comments.content,
        comments.item_id,
        comments.user_id,
        comments.created_at,
        u.username AS author_username
      FROM comments
      JOIN users u ON u.id = comments.user_id
      WHERE comments.id = ? AND comments.item_id = ?`,
    [commentId, itemId]
  );

  return { comment: commentRows[0] };
}

async function deleteComment(itemId, commentId, userId) {
  const [rows] = await pool.execute(
    'SELECT user_id FROM comments WHERE id = ? AND item_id = ?',
    [commentId, itemId]
  );

  if (!rows[0]) return { notFound: true };
  if (Number(rows[0].user_id) !== Number(userId)) return { forbidden: true };

  await pool.execute('DELETE FROM comments WHERE id = ? AND item_id = ?', [commentId, itemId]);
  return { deleted: true };
}

module.exports = {
  getAll,
  getById,
  create,
  update,
  remove,
  likeAdd,
  likeRemove,
  addComment,
  updateComment,
  deleteComment,
};

