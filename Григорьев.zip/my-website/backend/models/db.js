const mysql = require('mysql2/promise');
require('dotenv').config();

function createPool() {
  const { DB_HOST, DB_USER, DB_PASS, DB_NAME } = process.env;

  return mysql.createPool({
    host: DB_HOST || 'localhost',
    user: DB_USER || 'root',
    password: DB_PASS || '',
    database: DB_NAME || 'my_website_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    // JSON колонки MySQL иногда возвращаются строкой — приводим к объекту.
    typeCast: function castField(field, next) {
      if (field.type === 'JSON') {
        const val = next();
        if (val == null) return val;
        if (typeof val === 'string') {
          try {
            return JSON.parse(val);
          } catch {
            return val;
          }
        }
        return val;
      }
      return next();
    },
  });
}

const pool = createPool();

module.exports = { pool };

