const express = require('express');
const { auth } = require('../middleware/auth');
const itemController = require('../controllers/itemController');

const router = express.Router();

// Список/поиск
router.get('/', itemController.getAll);

// Одна запись (вместе с комментариями)
router.get('/:id', itemController.getById);

// CRUD (защищено)
router.post('/', auth, itemController.create);
router.put('/:id', auth, itemController.update);
router.delete('/:id', auth, itemController.remove);

// Лайки
router.post('/:id/likes', auth, itemController.likeAdd);
router.delete('/:id/likes', auth, itemController.likeRemove);

// Комментарии
router.post('/:id/comments', auth, itemController.addComment);
router.put('/:id/comments/:cid', auth, itemController.updateComment);
router.delete('/:id/comments/:cid', auth, itemController.deleteComment);

module.exports = router;

