const express = require('express');
const { auth } = require('../middleware/auth');
const authController = require('../controllers/authController');

const router = express.Router();

router.post('/auth/register', authController.register);
router.post('/auth/login', authController.login);
router.post('/auth/logout', auth, authController.logout);
router.get('/users/me', auth, authController.me);

module.exports = router;

