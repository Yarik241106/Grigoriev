const request = require('supertest');
const mysql = require('mysql2/promise');

const app = require('../app');

function getEnv(name, fallback) {
  return process.env[name] != null && process.env[name] !== '' ? process.env[name] : fallback;
}

async function tryConnect() {
  const { DB_HOST, DB_USER, DB_PASS, DB_NAME } = {
    DB_HOST: getEnv('DB_HOST', 'localhost'),
    DB_USER: getEnv('DB_USER', 'root'),
    DB_PASS: getEnv('DB_PASS', ''),
    DB_NAME: getEnv('DB_NAME', 'my_website_db'),
  };
  const conn = await mysql.createConnection({
    host: DB_HOST,
    user: DB_USER,
    password: DB_PASS,
    database: DB_NAME,
  });
  await conn.query('SELECT 1');
  await conn.end();
  return true;
}

describe('SIP Project API', () => {
  let dbAvailable = false;
  let baseEmail = `test_${Date.now()}@mail.ru`;

  beforeAll(async () => {
    process.env.JWT_SECRET = process.env.JWT_SECRET || 'test_secret';
    try {
      dbAvailable = await tryConnect();
    } catch {
      dbAvailable = false;
    }
  });

  beforeEach(async () => {
    if (!dbAvailable) return;
    const { DB_HOST, DB_USER, DB_PASS, DB_NAME } = {
      DB_HOST: getEnv('DB_HOST', 'localhost'),
      DB_USER: getEnv('DB_USER', 'root'),
      DB_PASS: getEnv('DB_PASS', ''),
      DB_NAME: getEnv('DB_NAME', 'my_website_db'),
    };

    const conn = await mysql.createConnection({
      host: DB_HOST,
      user: DB_USER,
      password: DB_PASS,
      database: DB_NAME,
    });

    // Удаляем в правильном порядке, чтобы не упереться в FK.
    await conn.query('SET FOREIGN_KEY_CHECKS=0');
    await conn.query('DELETE FROM comments');
    await conn.query('DELETE FROM likes');
    await conn.query('DELETE FROM items');
    await conn.query('DELETE FROM users');
    await conn.query('SET FOREIGN_KEY_CHECKS=1');

    await conn.end();
  });

  test('auth register/login flow', async () => {
    if (!dbAvailable) return;

    const username = 'student1';
    const password = '12345';

    const reg = await request(app).post('/api/auth/register').send({
      username,
      email: baseEmail,
      password,
    });
    expect(reg.status).toBe(201);
    expect(reg.body).toHaveProperty('id');

    const login = await request(app).post('/api/auth/login').send({
      email: baseEmail,
      password,
    });
    expect(login.status).toBe(200);
    expect(login.body).toHaveProperty('token');
    expect(typeof login.body.token).toBe('string');
  });

  test('items CRUD + likes + comments', async () => {
    if (!dbAvailable) return;

    const password = '12345';
    const username = 'student2';

    const reg = await request(app).post('/api/auth/register').send({
      username,
      email: baseEmail,
      password,
    });
    expect(reg.status).toBe(201);

    const login = await request(app).post('/api/auth/login').send({
      email: baseEmail,
      password,
    });
    const token = login.body.token;

    const created = await request(app)
      .post('/api/items')
      .set('Authorization', `Bearer ${token}`)
      .send({ title: 'Тест', content: 'Контент', tags: ['тест'] });
    expect(created.status).toBe(201);
    expect(created.body).toHaveProperty('id');

    const itemId = created.body.id;

    const list = await request(app).get('/api/items?page=1&limit=10');
    expect(list.status).toBe(200);

    const one = await request(app).get(`/api/items/${itemId}`);
    expect(one.status).toBe(200);
    expect(one.body).toHaveProperty('item');
    expect(one.body.item).toHaveProperty('title', 'Тест');

    const likeAdd = await request(app)
      .post(`/api/items/${itemId}/likes`)
      .set('Authorization', `Bearer ${token}`);
    expect(likeAdd.status).toBe(200);
    expect(likeAdd.body).toHaveProperty('likes_count');

    const likeRemove = await request(app)
      .delete(`/api/items/${itemId}/likes`)
      .set('Authorization', `Bearer ${token}`);
    expect(likeRemove.status).toBe(200);

    const commentCreate = await request(app)
      .post(`/api/items/${itemId}/comments`)
      .set('Authorization', `Bearer ${token}`)
      .send({ content: 'Комментарий 1' });
    expect(commentCreate.status).toBe(201);
    expect(commentCreate.body).toHaveProperty('id');
    const cid = commentCreate.body.id;

    const commentUpdate = await request(app)
      .put(`/api/items/${itemId}/comments/${cid}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ content: 'Комментарий обновлен' });
    expect(commentUpdate.status).toBe(200);

    const commentDelete = await request(app)
      .delete(`/api/items/${itemId}/comments/${cid}`)
      .set('Authorization', `Bearer ${token}`);
    expect(commentDelete.status).toBe(200);
  });
});

