const STORAGE_KEYS = {
  db: 'sip_html_db_v1',
  session: 'sip_html_session_v1',
};

const ADMIN = {
  // Учетка создаётся автоматически при первом запуске (если users ещё нет)
  email: 'admin@local',
  password: 'admin123',
  username: 'admin',
};

function nowIso() {
  return new Date().toISOString();
}

function uid() {
  return Math.random().toString(16).slice(2) + '_' + Date.now().toString(16);
}

function loadDb() {
  const raw = localStorage.getItem(STORAGE_KEYS.db);
  if (raw) return JSON.parse(raw);
  return {
    users: [],
    items: [],
  };
}

function saveDb(db) {
  localStorage.setItem(STORAGE_KEYS.db, JSON.stringify(db));
}

function getSession() {
  const raw = localStorage.getItem(STORAGE_KEYS.session);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function setSession(session) {
  if (!session) localStorage.removeItem(STORAGE_KEYS.session);
  else localStorage.setItem(STORAGE_KEYS.session, JSON.stringify(session));
}

function getCurrentUser() {
  const s = getSession();
  if (!s) return null;
  const db = loadDb();
  return db.users.find((u) => u.id === s.userId) || null;
}

function isAdmin(user) {
  return user && String(user.email).toLowerCase() === ADMIN.email.toLowerCase();
}

function seedAdminIfNeeded() {
  const db = loadDb();
  if (!Array.isArray(db.users)) db.users = [];
  if (!Array.isArray(db.items)) db.items = [];

  const adminExists = db.users.some((u) => String(u.email).toLowerCase() === ADMIN.email.toLowerCase());
  if (adminExists) return;

  db.users.push({
    id: uid(),
    username: ADMIN.username,
    email: ADMIN.email.toLowerCase(),
    password: ADMIN.password, // demo-only
    createdAt: nowIso(),
  });
  saveDb(db);
}

function parseTags(tagsText) {
  return tagsText
    .split(',')
    .map((t) => t.trim())
    .filter(Boolean)
    .slice(0, 20);
}

function escapeHtml(str) {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleString();
}

function renderAuthPage() {
  const user = getCurrentUser();
  const content = document.getElementById('content');

  if (user) {
    content.innerHTML = `
      <div class="panel">
        <h2>Вы уже авторизованы</h2>
        <div class="muted">Пользователь: <b>${escapeHtml(user.username)}</b></div>
        <div style="margin-top: 14px;">
          <a class="btn" href="#/" style="text-decoration:none; display:inline-block;">Перейти к постам</a>
        </div>
      </div>
    `;
    return;
  }

  content.innerHTML = `
    <div class="panel">
      <h2>Авторизация</h2>
      <div class="row" style="margin-bottom: 10px;">
        <button class="btn" type="button" id="tabLogin">Вход</button>
        <button class="btn" type="button" id="tabRegister" style="background: rgba(78, 161, 255, 0.06);">Регистрация</button>
      </div>

      <div id="authError" class="error" style="display:none;"></div>

      <div id="boxLogin">
        <form id="loginForm">
          <div class="field">
            <label>Email</label>
            <input name="email" type="email" required />
          </div>
          <div class="field">
            <label>Пароль</label>
            <input name="password" type="password" required />
          </div>
          <button class="btn" type="submit">Войти</button>
        </form>
      </div>

      <div id="boxRegister" style="display:none;">
        <form id="registerForm">
          <div class="field">
            <label>Имя пользователя</label>
            <input name="username" required />
          </div>
          <div class="field">
            <label>Email</label>
            <input name="email" type="email" required />
          </div>
          <div class="field">
            <label>Пароль</label>
            <input name="password" type="password" required />
          </div>
          <button class="btn" type="submit">Создать аккаунт</button>
        </form>
      </div>

      <div class="muted" style="margin-top: 14px;">
        В этой версии пароль хранится в <code>localStorage</code> (только для демонстрации).
      </div>
    </div>
  `;

  const authError = document.getElementById('authError');
  const showError = (msg) => {
    authError.textContent = msg;
    authError.style.display = 'block';
  };

  const tabLogin = document.getElementById('tabLogin');
  const tabRegister = document.getElementById('tabRegister');
  const boxLogin = document.getElementById('boxLogin');
  const boxRegister = document.getElementById('boxRegister');
  tabLogin.addEventListener('click', () => {
    tabLogin.style.background = 'rgba(78, 161, 255, 0.18)';
    tabRegister.style.background = 'rgba(78, 161, 255, 0.06)';
    boxLogin.style.display = 'block';
    boxRegister.style.display = 'none';
    authError.style.display = 'none';
  });
  tabRegister.addEventListener('click', () => {
    tabRegister.style.background = 'rgba(78, 161, 255, 0.18)';
    tabLogin.style.background = 'rgba(78, 161, 255, 0.06)';
    boxLogin.style.display = 'none';
    boxRegister.style.display = 'block';
    authError.style.display = 'none';
  });

  document.getElementById('registerForm').addEventListener('submit', (e) => {
    e.preventDefault();
    authError.style.display = 'none';

    const fd = new FormData(e.target);
    const username = String(fd.get('username') || '').trim();
    const email = String(fd.get('email') || '').trim().toLowerCase();
    const password = String(fd.get('password') || '');
    if (!username || !email || !password) return showError('Заполните все поля.');

    const db = loadDb();
    if (db.users.some((u) => u.email === email)) return showError('Email уже занят.');

    const newUser = {
      id: uid(),
      username,
      email,
      password,
      createdAt: nowIso(),
    };
    db.users.push(newUser);
    saveDb(db);
    setSession({ userId: newUser.id });
    location.hash = '#/';
  });

  document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    authError.style.display = 'none';

    const fd = new FormData(e.target);
    const email = String(fd.get('email') || '').trim().toLowerCase();
    const password = String(fd.get('password') || '');

    const db = loadDb();
    const user = db.users.find((u) => u.email === email && u.password === password);
    if (!user) return showError('Неверные данные.');

    setSession({ userId: user.id });
    location.hash = '#/';
  });
}

function renderItemsPage() {
  const user = getCurrentUser();
  const content = document.getElementById('content');

  const box = document.createElement('div');
  box.className = 'panel';
  box.innerHTML = `
    <h2 style="margin-bottom: 12px;">Лента постов</h2>
    <div class="row" style="align-items: flex-end; margin-bottom: 14px;">
      <div class="field" style="margin-bottom: 0;">
        <label>Поиск (название/теги)</label>
        <input id="searchInput" placeholder="Например: тест" />
      </div>
      <button class="btn" id="searchBtn" type="button">Найти</button>
      <button class="linkButton" id="resetSearchBtn" type="button">Сброс</button>
    </div>

    <div id="paginationMeta" class="muted" style="margin-bottom: 12px;"></div>

    <div id="itemsList"></div>
  `;

  const createBox = document.createElement('div');
  createBox.className = 'panel';
  createBox.style.marginBottom = '16px';
  createBox.innerHTML = `
    <h3 style="margin-bottom: 10px;">Создать пост</h3>
    ${user ? '' : '<div class="muted" style="margin-bottom: 12px;">Войдите, чтобы создавать посты.</div>'}
    <div id="createError" class="error" style="display:none;"></div>
    <form id="createForm">
      <div class="field">
        <label>Заголовок</label>
        <input name="title" required ${user ? '' : 'disabled'} />
      </div>
      <div class="field">
        <label>Контент</label>
        <textarea name="content" required ${user ? '' : 'disabled'}></textarea>
      </div>
      <div class="field">
        <label>Теги (через запятую)</label>
        <input name="tags" placeholder="тест, новости" ${user ? '' : 'disabled'} />
      </div>
      <button class="btn" type="submit" ${user ? '' : 'disabled'}>Создать</button>
    </form>
  `;

  content.innerHTML = '';
  content.appendChild(createBox);
  content.appendChild(box);

  const db = loadDb();
  // eslint-disable-next-line no-unused-vars
  let page = 1;
  const limit = 10;
  let search = '';

  const getUserById = (uid) => db.users.find((u) => u.id === uid);

  const setMeta = (meta) => {
    const el = document.getElementById('paginationMeta');
    el.textContent = meta
      ? `Страница ${meta.page} из ${meta.totalPages} • Всего: ${meta.total}`
      : '';
  };

  const getFilteredItems = () => {
    const stateDb = loadDb(); // обновляем, потому что есть CRUD
    const q = search.trim().toLowerCase();
    let items = stateDb.items.slice();
    items.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));

    if (!q) return items;

    return items.filter((it) => {
      const titleOk = String(it.title || '').toLowerCase().includes(q);
      const tagsStr = Array.isArray(it.tags) ? it.tags.join(' ') : '';
      const tagsOk = String(tagsStr).toLowerCase().includes(q);
      return titleOk || tagsOk;
    });
  };

  const renderComments = (item, parentEl) => {
    const stateDb = loadDb();
    const itemFresh = stateDb.items.find((x) => x.id === item.id);
    const comments = (itemFresh && Array.isArray(itemFresh.comments)) ? itemFresh.comments : [];

    const canEdit = !!user;
    parentEl.innerHTML = `
      <h4 style="margin: 0 0 8px;">Комментарии</h4>
      ${canEdit ? '' : '<div class="muted" style="margin-bottom: 10px;">Войдите, чтобы оставлять комментарии.</div>'}

      <div class="field" style="margin-bottom: 10px;">
        <label>Добавить комментарий</label>
        <input id="commentInput" ${canEdit ? '' : 'disabled'} placeholder="Ваш комментарий" />
      </div>
      <button class="btn" type="button" id="addCommentBtn" ${canEdit ? '' : 'disabled'}>Добавить</button>
      <div style="height: 12px;"></div>

      <div id="commentsList" style="display:flex; flex-direction:column; gap: 10px;"></div>
    `;

    const commentsList = parentEl.querySelector('#commentsList');
    if (!comments.length) {
      commentsList.innerHTML = `<div class="muted">Пока комментариев нет.</div>`;
      return;
    }

    const stateDb2 = loadDb();
    const getName = (uid) => stateDb2.users.find((u) => u.id === uid)?.username || '—';

    comments
      .slice()
      .sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)))
      .forEach((c) => {
        const el = document.createElement('div');
        el.className = 'itemCard';
        el.innerHTML = `
          <div class="muted" style="margin-bottom: 6px;">
            ${escapeHtml(getName(c.userId))} • ${formatDate(c.createdAt)}
          </div>
          <div style="white-space: pre-wrap;">${escapeHtml(c.content || '')}</div>
          ${canEdit ? `
            <div style="display:flex; gap: 10px; flex-wrap: wrap; margin-top: 10px;">
              <button class="btn" type="button" data-cid="${c.id}" data-action="edit">Редактировать</button>
              <button class="linkButton" type="button" data-cid="${c.id}" data-action="del">Удалить</button>
            </div>
          ` : ''}
        `;
        commentsList.appendChild(el);
      });

    parentEl.querySelector('#addCommentBtn').addEventListener('click', () => {
      const input = parentEl.querySelector('#commentInput');
      const text = String(input.value || '').trim();
      if (!text) return;

      const db3 = loadDb();
      const itemIdx = db3.items.findIndex((x) => x.id === item.id);
      if (itemIdx === -1) return;

      db3.items[itemIdx].comments.push({
        id: uid(),
        userId: user.id,
        content: text,
        createdAt: nowIso(),
      });
      saveDb(db3);
      renderItemsAfterState();
    });

    parentEl.querySelectorAll('button[data-action]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const cid = btn.getAttribute('data-cid');
        const action = btn.getAttribute('data-action');

        const stateDb3 = loadDb();
        const itemFresh2 = stateDb3.items.find((x) => x.id === item.id);
        const comment = itemFresh2?.comments?.find((x) => x.id === cid);
        if (!comment) return;
        if (!user || comment.userId !== user.id) {
          alert('Редактировать/удалять может только автор комментария.');
          return;
        }

        if (action === 'del') {
          if (!confirm('Удалить комментарий?')) return;
          const idx = stateDb3.items.findIndex((x) => x.id === item.id);
          stateDb3.items[idx].comments = stateDb3.items[idx].comments.filter((x) => x.id !== cid);
          saveDb(stateDb3);
          renderItemsAfterState();
          return;
        }

        const newText = prompt('Текст комментария:', comment.content);
        if (newText == null) return;
        const idx = stateDb3.items.findIndex((x) => x.id === item.id);
        const cidx = stateDb3.items[idx].comments.findIndex((x) => x.id === cid);
        stateDb3.items[idx].comments[cidx].content = String(newText).trim();
        saveDb(stateDb3);
        renderItemsAfterState();
      });
    });
  };

  const likeToggle = (itemId) => {
    const stateDb3 = loadDb();
    const idx = stateDb3.items.findIndex((x) => x.id === itemId);
    if (idx === -1) return;
    const it = stateDb3.items[idx];
    const likesBy = Array.isArray(it.likesBy) ? it.likesBy : [];

    const liked = likesBy.includes(user.id);
    if (liked) it.likesBy = likesBy.filter((x) => x !== user.id);
    else it.likesBy = likesBy.concat([user.id]);

    saveDb(stateDb3);
    renderItemsAfterState();
  };

  function renderItemsAfterState() {
    // обновим ссылку на актуальные данные через reloadDb-логикой
    const stateDb4 = loadDb();
    // eslint-disable-next-line no-unused-vars
    const items = getFilteredItems();
    const total = items.length;
    const totalPages = Math.max(1, Math.ceil(total / limit));
    page = Math.min(Math.max(1, page), totalPages);

    setMeta({ page, total, totalPages });

    const itemsList = document.getElementById('itemsList');
    itemsList.innerHTML = '';

    const slice = items.slice((page - 1) * limit, page * limit);
    if (!slice.length) {
      itemsList.innerHTML = `<div class="muted">Пока постов нет.</div>`;
      return;
    }

    slice.forEach((item) => {
      const owner = stateDb4.users.find((u) => u.id === item.userId);
      const likesCount = (Array.isArray(item.likesBy) ? item.likesBy : []).length;
      const commentsCount = Array.isArray(item.comments) ? item.comments.length : 0;
      const liked = user ? Array.isArray(item.likesBy) && item.likesBy.includes(user.id) : false;
      const isOwner = user && item.userId === user.id;

      const wrapper = document.createElement('div');
      wrapper.className = 'itemCard';

      const tags = Array.isArray(item.tags) ? item.tags : [];
      const tagsHtml = tags.length
        ? `<div style="margin-top: 10px;">${tags.slice(0, 10).map((t) => `<span class="tag">${escapeHtml(t)}</span>`).join('')}</div>`
        : '';

      wrapper.innerHTML = `
        <div style="display:flex; justify-content:space-between; gap: 14px; flex-wrap:wrap;">
          <div style="min-width: 250px;">
            <h3 style="margin: 0 0 8px;">${escapeHtml(item.title || '')}</h3>
            <div class="muted" style="margin-bottom: 8px;">
              ${escapeHtml(owner?.username || '—')} • ${formatDate(item.createdAt)}
            </div>
          </div>
          <div style="display:flex; gap: 10px; align-items:flex-start;">
            <button class="btn" type="button" ${user ? '' : 'disabled'}>${liked ? 'Убрать лайк' : 'Лайк'} (${likesCount})</button>
            <button class="linkButton" type="button">Комментарии (${commentsCount})</button>
          </div>
        </div>
        <div style="white-space: pre-wrap; margin-top: 8px;">${escapeHtml(item.content || '')}</div>
        ${tagsHtml}
        ${
          isOwner
            ? `
          <div style="display:flex; gap: 10px; flex-wrap: wrap; margin-top: 10px;">
            <button class="btn" type="button" data-action="edit" data-itemid="${item.id}">Редактировать</button>
            <button class="linkButton" type="button" data-action="del" data-itemid="${item.id}">Удалить</button>
          </div>
        `
            : ''
        }
        <div class="error" style="display:none; margin-top: 12px;" role="alert"></div>
        <div style="margin-top: 14px; display:none;" class="commentsBox"></div>
      `;

      const likeBtn = wrapper.querySelector('button.btn');
      const commentsBtn = wrapper.querySelectorAll('button')[1];
      const commentsBox = wrapper.querySelector('.commentsBox');

      likeBtn.addEventListener('click', () => {
        if (!user) return;
        likeToggle(item.id);
      });

      commentsBtn.addEventListener('click', () => {
        const visible = commentsBox.style.display !== 'none';
        commentsBox.style.display = visible ? 'none' : 'block';
        if (!visible) renderComments(item, commentsBox);
      });

      // CRUD for owner
      const editBtn = wrapper.querySelector('button[data-action="edit"]');
      const delBtn = wrapper.querySelector('button[data-action="del"]');
      if (editBtn) {
        editBtn.addEventListener('click', () => {
          if (!user) return;
          const nextTitle = prompt('Новый заголовок:', item.title);
          if (nextTitle == null) return;
          const nextContent = prompt('Новый контент:', item.content);
          if (nextContent == null) return;
          const nextTagsText = prompt(
            'Новые теги (через запятую):',
            Array.isArray(item.tags) ? item.tags.join(', ') : ''
          );
          if (nextTagsText == null) return;

          const stateDb5 = loadDb();
          const idx = stateDb5.items.findIndex((x) => x.id === item.id);
          if (idx === -1) return;

          stateDb5.items[idx].title = String(nextTitle).trim();
          stateDb5.items[idx].content = String(nextContent).trim();
          stateDb5.items[idx].tags = parseTags(String(nextTagsText));
          saveDb(stateDb5);
          renderItemsAfterState();
        });
      }
      if (delBtn) {
        delBtn.addEventListener('click', () => {
          if (!user) return;
          if (!confirm('Удалить пост?')) return;
          const stateDb6 = loadDb();
          stateDb6.items = stateDb6.items.filter((x) => x.id !== item.id);
          saveDb(stateDb6);
          renderItemsAfterState();
        });
      }

      itemsList.appendChild(wrapper);
    });

    const pager = document.createElement('div');
    pager.className = 'panel';
    pager.style.marginTop = '16px';
    pager.innerHTML = `
      <div style="display:flex; justify-content:space-between; gap: 12px; flex-wrap:wrap;">
        <button class="btn" type="button" ${page <= 1 ? 'disabled' : ''}>Назад</button>
        <button class="btn" type="button" ${page >= totalPages ? 'disabled' : ''}>Дальше</button>
      </div>
    `;
    const [backBtn, nextBtn] = pager.querySelectorAll('button');
    backBtn.addEventListener('click', () => {
      page = Math.max(1, page - 1);
      renderItemsAfterState();
    });
    nextBtn.addEventListener('click', () => {
      page = Math.min(totalPages, page + 1);
      renderItemsAfterState();
    });

    itemsList.appendChild(pager);
  }

  // Create form
  const createError = document.getElementById('createError');
  const showCreateError = (msg) => {
    createError.textContent = msg;
    createError.style.display = 'block';
  };

  document.getElementById('createForm').addEventListener('submit', (e) => {
    e.preventDefault();
    if (!user) return;
    createError.style.display = 'none';

    const fd = new FormData(e.target);
    const title = String(fd.get('title') || '').trim();
    const content = String(fd.get('content') || '').trim();
    const tags = parseTags(String(fd.get('tags') || ''));
    if (!title || !content) return showCreateError('Заголовок и контент обязательны.');

    const stateDb = loadDb();
    const newItem = {
      id: uid(),
      title,
      content,
      tags,
      userId: user.id,
      createdAt: nowIso(),
      likesBy: [],
      comments: [],
    };
    stateDb.items.push(newItem);
    saveDb(stateDb);
    e.target.reset();
    renderItemsAfterState();
  });

  // Search
  document.getElementById('searchBtn').addEventListener('click', () => {
    search = String(document.getElementById('searchInput').value || '');
    page = 1;
    renderItemsAfterState();
  });
  document.getElementById('resetSearchBtn').addEventListener('click', () => {
    document.getElementById('searchInput').value = '';
    search = '';
    page = 1;
    renderItemsAfterState();
  });

  renderItemsAfterState();
}

function renderLayoutBySession() {
  const user = getCurrentUser();
  const logoutBtn = document.getElementById('logoutBtn');
  logoutBtn.style.display = user ? 'inline-block' : 'none';

  const adminLink = document.getElementById('adminLink');
  adminLink.style.display = isAdmin(user) ? 'inline-block' : 'none';
}

function init() {
  seedAdminIfNeeded();
  renderLayoutBySession();

  document.getElementById('logoutBtn').addEventListener('click', () => {
    setSession(null);
    renderLayoutBySession();
    location.hash = '#/auth';
  });

  function route() {
    const hash = location.hash || '#/';
    if (hash.startsWith('#/auth')) renderAuthPage();
    else if (hash.startsWith('#/admin')) renderAdminPage();
    else renderItemsPage();
  }

  window.addEventListener('hashchange', () => route());
  route();
}

init();

function renderAdminPage() {
  const user = getCurrentUser();
  const content = document.getElementById('content');

  if (!user) {
    content.innerHTML = `
      <div class="panel">
        <h2>Админ-панель</h2>
        <div class="muted">Нужно войти. Учетка админа: <b>${escapeHtml(ADMIN.email)}</b> / <b>${escapeHtml(ADMIN.password)}</b></div>
        <div style="margin-top: 12px;">
          <a class="btn" href="#/auth" style="text-decoration:none; display:inline-block;">Перейти к входу</a>
        </div>
      </div>
    `;
    return;
  }

  if (!isAdmin(user)) {
    content.innerHTML = `
      <div class="panel">
        <h2>Админ-панель</h2>
        <div class="error" style="display:block;">Нет прав.</div>
        <div class="muted" style="margin-top: 10px;">Доступ только у администратора.</div>
      </div>
    `;
    return;
  }

  const db = loadDb();

  const computeStats = () => {
    const users = Array.isArray(db.users) ? db.users : [];
    const items = Array.isArray(db.items) ? db.items : [];

    const itemsByUser = new Map();
    const commentsByUser = new Map();
    const likesByUser = new Map();

    users.forEach((u) => {
      itemsByUser.set(u.id, 0);
      commentsByUser.set(u.id, 0);
      likesByUser.set(u.id, 0);
    });

    items.forEach((it) => {
      if (itemsByUser.has(it.userId)) itemsByUser.set(it.userId, (itemsByUser.get(it.userId) || 0) + 1);
      const comments = Array.isArray(it.comments) ? it.comments : [];
      comments.forEach((c) => {
        const uid = c.userId;
        if (commentsByUser.has(uid)) commentsByUser.set(uid, (commentsByUser.get(uid) || 0) + 1);
      });
      const likesBy = Array.isArray(it.likesBy) ? it.likesBy : [];
      likesBy.forEach((uid) => {
        if (likesByUser.has(uid)) likesByUser.set(uid, (likesByUser.get(uid) || 0) + 1);
      });
    });

    return users.map((u) => ({
      user: u,
      itemsCount: itemsByUser.get(u.id) || 0,
      commentsCount: commentsByUser.get(u.id) || 0,
      likesCount: likesByUser.get(u.id) || 0,
    }));
  };

  const allItems = Array.isArray(db.items) ? db.items : [];
  const allUsers = Array.isArray(db.users) ? db.users : [];

  const ownerName = (userId) => allUsers.find((u) => u.id === userId)?.username || '—';
  const getIdTitle = (item) => `${item.title || '(без названия)'}`;

  const allComments = [];
  allItems.forEach((it) => {
    const comments = Array.isArray(it.comments) ? it.comments : [];
    comments.forEach((c) => {
      allComments.push({
        id: c.id,
        content: c.content,
        createdAt: c.createdAt,
        userId: c.userId,
        itemId: it.id,
        itemTitle: it.title,
      });
    });
  });

  const stats = computeStats();

  const usersTable = `
    <div class="panel">
      <h2 style="margin-bottom: 12px;">Пользователи</h2>
      <div class="muted" style="margin-bottom: 10px;">Всего: ${allUsers.length}</div>
      <div style="display:flex; flex-direction:column; gap: 10px;">
        ${stats
          .slice()
          .sort((a, b) => String(a.user.createdAt).localeCompare(String(b.user.createdAt)))
          .map((s) => {
            const u = s.user;
            const isAdminUser = isAdmin(u);
            return `
              <div class="itemCard">
                <div style="display:flex; justify-content:space-between; gap: 14px; flex-wrap:wrap;">
                  <div style="min-width: 240px;">
                    <div style="font-weight: 700;">${escapeHtml(u.username)}</div>
                    <div class="muted">${escapeHtml(u.email)} • ${formatDate(u.createdAt)}</div>
                    <div class="muted">Постов: ${s.itemsCount} • Комментариев: ${s.commentsCount} • Лайков: ${s.likesCount}</div>
                    ${isAdminUser ? `<div class="muted" style="margin-top: 6px;">(Администратор)</div>` : ''}
                  </div>
                  <div style="display:flex; gap: 10px; align-items:flex-start; flex-wrap:wrap;">
                    <button class="linkButton" type="button" data-action="deleteUser" data-userid="${u.id}" ${isAdminUser ? 'disabled' : ''}>
                      Удалить пользователя
                    </button>
                  </div>
                </div>
              </div>
            `;
          })
          .join('')}
      </div>
    </div>
  `;

  const itemsTable = `
    <div class="panel" style="margin-top: 16px;">
      <h2 style="margin-bottom: 12px;">Посты</h2>
      <div class="muted" style="margin-bottom: 10px;">Всего: ${allItems.length}</div>
      <div style="display:flex; flex-direction:column; gap: 10px;">
        ${allItems
          .slice()
          .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
          .map((it) => {
            const commentsCount = Array.isArray(it.comments) ? it.comments.length : 0;
            const likesCount = Array.isArray(it.likesBy) ? it.likesBy.length : 0;
            const owner = ownerName(it.userId);
            return `
              <div class="itemCard">
                <div style="display:flex; justify-content:space-between; gap: 14px; flex-wrap:wrap;">
                  <div style="min-width: 260px;">
                    <div style="font-weight: 700;">${escapeHtml(getIdTitle(it))}</div>
                    <div class="muted">${escapeHtml(owner)} • ${formatDate(it.createdAt)}</div>
                    <div class="muted">Лайков: ${likesCount} • Комментариев: ${commentsCount}</div>
                  </div>
                  <div style="display:flex; gap: 10px; align-items:flex-start; flex-wrap:wrap;">
                    <button class="linkButton" type="button" data-action="deleteItem" data-itemid="${it.id}">
                      Удалить пост
                    </button>
                  </div>
                </div>
              </div>
            `;
          })
          .join('')}
      </div>
    </div>
  `;

  const commentsTable = `
    <div class="panel" style="margin-top: 16px;">
      <h2 style="margin-bottom: 12px;">Комментарии</h2>
      <div class="muted" style="margin-bottom: 10px;">Всего: ${allComments.length}</div>
      <div style="display:flex; flex-direction:column; gap: 10px;">
        ${
          allComments.length
            ? allComments
                .slice()
                .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
                .map((c) => {
                  return `
                    <div class="itemCard">
                      <div style="display:flex; justify-content:space-between; gap: 14px; flex-wrap:wrap;">
                        <div style="min-width: 260px;">
                          <div style="font-weight: 700;">${escapeHtml(ownerName(c.userId))}</div>
                          <div class="muted">${escapeHtml(c.itemTitle || '')} • ${formatDate(c.createdAt)}</div>
                          <div style="white-space: pre-wrap; margin-top: 8px;">${escapeHtml(c.content || '')}</div>
                        </div>
                        <div style="display:flex; gap: 10px; align-items:flex-start; flex-wrap:wrap;">
                          <button class="linkButton" type="button" data-action="deleteComment" data-itemid="${c.itemId}" data-cid="${c.id}">
                            Удалить комментарий
                          </button>
                        </div>
                      </div>
                    </div>
                  `;
                })
                .join('')
            : '<div class="muted">Пока нет комментариев.</div>'
        }
      </div>
    </div>
  `;

  const pageBox = document.createElement('div');
  pageBox.innerHTML = `
    <div class="panel" style="margin-bottom: 16px;">
      <h2>Админ-панель</h2>
      <div class="muted">
        Управление пользователями и контентом. Учетка админа: <b>${escapeHtml(ADMIN.email)}</b>
      </div>
    </div>
    ${usersTable}
    ${itemsTable}
    ${commentsTable}
  `;

  content.innerHTML = '';
  content.appendChild(pageBox);

  // Event handlers
  content.querySelectorAll('button[data-action]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const action = btn.getAttribute('data-action');
      if (action === 'deleteUser') {
        const targetUserId = btn.getAttribute('data-userid');
        if (String(targetUserId) === String(getCurrentUser().id)) return;
        if (!confirm('Удалить пользователя и его посты/активность?')) return;

        const db2 = loadDb();
        // удалить пользователя
        db2.users = (db2.users || []).filter((u) => u.id !== targetUserId);
        // удалить его посты и комментарии (FK-каскад логически повторяем вручную)
        db2.items = (db2.items || [])
          .filter((it) => it.userId !== targetUserId)
          .map((it) => {
            // убрать лайки этого пользователя в оставшихся постах
            if (Array.isArray(it.likesBy)) it.likesBy = it.likesBy.filter((uid) => uid !== targetUserId);
            // убрать комментарии (на случай, если вдруг остались)
            if (Array.isArray(it.comments)) it.comments = it.comments.filter((c) => c.userId !== targetUserId);
            return it;
          });
        saveDb(db2);
        location.hash = '#/admin';
      }

      if (action === 'deleteItem') {
        const itemId = btn.getAttribute('data-itemid');
        if (!confirm('Удалить пост?')) return;
        const db2 = loadDb();
        db2.items = (db2.items || []).filter((it) => String(it.id) !== String(itemId));
        saveDb(db2);
        location.hash = '#/admin';
      }

      if (action === 'deleteComment') {
        const itemId = btn.getAttribute('data-itemid');
        const cid = btn.getAttribute('data-cid');
        if (!confirm('Удалить комментарий?')) return;
        const db2 = loadDb();
        db2.items = (db2.items || []).map((it) => {
          if (String(it.id) !== String(itemId)) return it;
          if (!Array.isArray(it.comments)) return it;
          it.comments = it.comments.filter((c) => String(c.id) !== String(cid));
          return it;
        });
        saveDb(db2);
        location.hash = '#/admin';
      }
    });
  });
}

