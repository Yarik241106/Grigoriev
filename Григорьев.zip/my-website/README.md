# SIP Project: Full Web Site (Posts / Likes / Comments)

## Стек
- Frontend: React (routing, формы, работа с API)
- Backend: Node.js + Express + JWT
- База данных: MySQL (phpMyAdmin)
- Тесты: Jest + Supertest

## Тема
Личный блог / портфолио:
- `items` = посты (title/content/tags)
- лайки и комментарии постов
- поиск по названию и по тегам

## Старт проекта
### 1) База данных
1. Откройте phpMyAdmin
2. Создайте БД: `my_website_db`
3. Импортируйте `database/schema.sql`

### 2) Backend
1. `cd backend`
2. Создайте файл `.env` из `.env.example`:
   - `DB_HOST=localhost`
   - `DB_USER=root`
   - `DB_PASS=`
   - `DB_NAME=my_website_db`
   - `JWT_SECRET=some_secret`
   - `PORT=3001`
3. Установите зависимости: `npm install`
4. Запуск: `npm run dev` (или `npm start`)

Backend: `http://localhost:3001`

### 3) Frontend
1. `cd frontend`
2. `npm install`
3. Запуск: `npm start`

Frontend: `http://localhost:3000`

## API
### Auth
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/users/me`

### Items (posts)
- `GET /api/items?page=1&limit=10`
- `GET /api/items/:id`
- `POST /api/items`
- `PUT /api/items/:id`
- `DELETE /api/items/:id`

### Likes
- `POST /api/items/:id/likes`
- `DELETE /api/items/:id/likes`

### Comments
- `POST /api/items/:id/comments`
- `PUT /api/items/:id/comments/:cid`
- `DELETE /api/items/:id/comments/:cid`

### Search
- `GET /api/items?search=...`

## Тесты
- `cd backend && npm test`

