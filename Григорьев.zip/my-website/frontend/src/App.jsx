import React, { useEffect, useState } from 'react';
import { Link, Route, Routes, useNavigate } from 'react-router-dom';
import { clearToken, getToken } from './api/token';

import AuthPage from './pages/AuthPage.jsx';
import ItemsPage from './pages/ItemsPage.jsx';

export default function App() {
  const [token, setToken] = useState(() => getToken());
  const navigate = useNavigate();

  useEffect(() => {
    // Подстраховка: если токен поменяли вне приложения.
    setToken(getToken());
  }, []);

  const handleLogout = async () => {
    clearToken();
    setToken(null);
    navigate('/auth');
  };

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">SIP Блог</div>
        <nav className="nav">
          <Link to="/">Посты</Link>
          <Link to="/auth">Авторизация</Link>
          {token ? (
            <button className="linkButton" onClick={handleLogout} type="button">
              Выйти
            </button>
          ) : null}
        </nav>
      </header>

      <main className="main">
        <Routes>
          <Route path="/" element={<ItemsPage token={token} />} />
          <Route
            path="/auth"
            element={<AuthPage token={token} onAuth={(t) => setToken(t)} />}
          />
        </Routes>
      </main>
    </div>
  );
}

