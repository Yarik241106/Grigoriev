import React, { useState } from 'react';
import { apiFetch } from '../api/api';

export default function PostForm({ token, onCreated }) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tagsText, setTagsText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const parseTags = (text) => {
    return text
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean)
      .slice(0, 20);
  };

  const submit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const tags = parseTags(tagsText);
      await apiFetch('/api/items', {
        method: 'POST',
        token,
        body: { title, content, tags },
      });

      setTitle('');
      setContent('');
      setTagsText('');
      if (onCreated) await onCreated();
    } catch (err) {
      setError(err.message || 'Ошибка');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="panel" style={{ marginBottom: 16 }}>
      <h3>Создать пост</h3>
      {!token ? <div className="muted">Войдите в систему, чтобы создавать посты.</div> : null}
      {error ? <div className="error">{error}</div> : null}
      <form onSubmit={submit}>
        <div className="field">
          <label>Заголовок</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} required disabled={!token || loading} />
        </div>
        <div className="field">
          <label>Контент</label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            required
            disabled={!token || loading}
          />
        </div>
        <div className="field">
          <label>Теги (через запятую)</label>
          <input value={tagsText} onChange={(e) => setTagsText(e.target.value)} disabled={!token || loading} />
        </div>
        <button className="btn" disabled={!token || loading} type="submit">
          {loading ? 'Сохранение...' : 'Создать'}
        </button>
      </form>
    </div>
  );
}

