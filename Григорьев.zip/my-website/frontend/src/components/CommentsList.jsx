import React, { useMemo, useState } from 'react';
import { apiFetch } from '../api/api';

export default function CommentsList({ token, itemId, comments = [], onRefresh }) {
  const [content, setContent] = useState('');
  const [error, setError] = useState(null);
  const [editingCid, setEditingCid] = useState(null);
  const [editingText, setEditingText] = useState('');
  const canEdit = !!token;

  const sortedComments = useMemo(() => comments.slice(), [comments]);

  const create = async () => {
    setError(null);
    try {
      await apiFetch(`/api/items/${itemId}/comments`, {
        method: 'POST',
        token,
        body: { content },
      });
      setContent('');
      if (onRefresh) await onRefresh();
    } catch (err) {
      setError(err.message || 'Ошибка');
    }
  };

  const update = async (cid) => {
    setError(null);
    try {
      await apiFetch(`/api/items/${itemId}/comments/${cid}`, {
        method: 'PUT',
        token,
        body: { content: editingText },
      });
      setEditingCid(null);
      setEditingText('');
      if (onRefresh) await onRefresh();
    } catch (err) {
      setError(err.message || 'Ошибка');
    }
  };

  const remove = async (cid) => {
    setError(null);
    try {
      await apiFetch(`/api/items/${itemId}/comments/${cid}`, {
        method: 'DELETE',
        token,
      });
      if (onRefresh) await onRefresh();
    } catch (err) {
      setError(err.message || 'Ошибка');
    }
  };

  return (
    <div style={{ marginTop: 12 }}>
      <h4 style={{ margin: '0 0 8px' }}>Комментарии</h4>
      {error ? <div className="error">{error}</div> : null}

      {!canEdit ? <div className="muted">Войдите, чтобы оставлять комментарии.</div> : null}

      <div className="field" style={{ marginBottom: 8 }}>
        <label>Добавить комментарий</label>
        <input
          value={content}
          onChange={(e) => setContent(e.target.value)}
          disabled={!canEdit}
        />
      </div>
      <button className="btn" disabled={!canEdit || !content.trim()} type="button" onClick={create}>
        Добавить
      </button>

      <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {sortedComments.length === 0 ? <div className="muted">Пока комментариев нет.</div> : null}
        {sortedComments.map((c) => (
          <div key={c.id} className="itemCard">
            <div className="muted" style={{ marginBottom: 6 }}>
              {c.author_username || '—'} • {c.created_at ? new Date(c.created_at).toLocaleString() : ''}
            </div>
            {editingCid === c.id ? (
              <div className="field" style={{ marginBottom: 8 }}>
                <input
                  value={editingText}
                  onChange={(e) => setEditingText(e.target.value)}
                />
                <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 8 }}>
                  <button className="btn" type="button" onClick={() => update(c.id)} disabled={!editingText.trim()}>
                    Сохранить
                  </button>
                  <button
                    className="linkButton"
                    type="button"
                    onClick={() => {
                      setEditingCid(null);
                      setEditingText('');
                    }}
                  >
                    Отмена
                  </button>
                </div>
              </div>
            ) : (
              <div style={{ whiteSpace: 'pre-wrap' }}>{c.content}</div>
            )}

            {canEdit ? (
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 10 }}>
                <button
                  className="btn"
                  type="button"
                  onClick={() => {
                    setEditingCid(c.id);
                    setEditingText(c.content);
                  }}
                >
                  Редактировать
                </button>
                <button className="linkButton" type="button" onClick={() => remove(c.id)}>
                  Удалить
                </button>
              </div>
            ) : null}
          </div>
        ))}
      </div>
    </div>
  );
}

