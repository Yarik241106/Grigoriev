import React, { useEffect, useState } from 'react';
import { apiFetch } from '../api/api';
import CommentsList from './CommentsList.jsx';

export default function PostCard({ item, token, onRefreshList }) {
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(item.likes_count || 0);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [details, setDetails] = useState(null);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLikesCount(item.likes_count || 0);
  }, [item.likes_count]);

  const refreshDetails = async () => {
    if (!detailsOpen) return;
    setLoadingDetails(true);
    setError(null);
    try {
      const data = await apiFetch(`/api/items/${item.id}`);
      setDetails(data);
    } catch (e) {
      setError(e.message || 'Ошибка');
    } finally {
      setLoadingDetails(false);
    }
  };

  useEffect(() => {
    if (detailsOpen) {
      refreshDetails();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [detailsOpen]);

  const like = async () => {
    setError(null);
    try {
      const resp = liked
        ? await apiFetch(`/api/items/${item.id}/likes`, { method: 'DELETE', token })
        : await apiFetch(`/api/items/${item.id}/likes`, { method: 'POST', token });
      setLiked(!liked);
      setLikesCount(resp.likes_count);
      if (onRefreshList) await onRefreshList();
    } catch (e) {
      setError(e.message || 'Ошибка');
    }
  };

  return (
    <div className="itemCard" style={{ marginBottom: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 14, flexWrap: 'wrap' }}>
        <div style={{ minWidth: 250 }}>
          <h3 style={{ margin: '0 0 8px' }}>{item.title}</h3>
          <div className="muted" style={{ marginBottom: 8 }}>
            {item.author_username || '—'} • {item.created_at ? new Date(item.created_at).toLocaleString() : ''}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <button className="btn" type="button" onClick={like} disabled={!token}>
            {liked ? 'Убрать лайк' : 'Лайк'} ({likesCount})
          </button>
          <button className="linkButton" type="button" onClick={() => setDetailsOpen((s) => !s)}>
            {detailsOpen ? 'Скрыть' : 'Комментарии'} ({item.comments_count || 0})
          </button>
        </div>
      </div>

      <div style={{ whiteSpace: 'pre-wrap', marginTop: 8 }}>{item.content}</div>

      {Array.isArray(item.tags) && item.tags.length ? (
        <div style={{ marginTop: 10 }}>
          {item.tags.slice(0, 10).map((t, idx) => (
            <span key={`${t}_${idx}`} className="tag">
              {t}
            </span>
          ))}
        </div>
      ) : null}

      {error ? <div className="error" style={{ marginTop: 12 }}>{error}</div> : null}

      {detailsOpen ? (
        <div style={{ marginTop: 14 }}>
          {loadingDetails && !details ? <div className="muted">Загрузка деталей...</div> : null}
          {details ? (
            <CommentsList
              token={token}
              itemId={item.id}
              comments={details.comments || []}
              onRefresh={refreshDetails}
            />
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

