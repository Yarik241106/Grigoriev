import React, { useState } from 'react';
import { apiFetch } from '../api/api';

export default function AuthPage({ onAuth }) {
  const [mode, setMode] = useState('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [registerForm, setRegisterForm] = useState({
    username: '',
    email: '',
    password: '',
  });

  const [loginForm, setLoginForm] = useState({
    email: '',
    password: '',
  });

  const submit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      if (mode === 'register') {
        await apiFetch('/api/auth/register', {
          method: 'POST',
          body: registerForm,
        });
      }

      const loginResp = await apiFetch('/api/auth/login', {
        method: 'POST',
        body: mode === 'register' ? { email: registerForm.email, password: registerForm.password } : loginForm,
      });

      onAuth(loginResp.token);
    } catch (err) {
      setError(err.message || 'Ошибка');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="panel">
      <h2>{mode === 'login' ? 'Вход' : 'Регистрация'}</h2>
      <div className="row" style={{ marginBottom: 10 }}>
        <button className="btn" type="button" onClick={() => setMode('login')}>
          Вход
        </button>
        <button className="btn" type="button" onClick={() => setMode('register')}>
          Регистрация
        </button>
      </div>

      {error ? <div className="error">{error}</div> : null}

      <form onSubmit={submit}>
        {mode === 'register' ? (
          <div className="field">
            <label>Имя пользователя</label>
            <input
              value={registerForm.username}
              onChange={(e) => setRegisterForm((s) => ({ ...s, username: e.target.value }))}
              required
            />
          </div>
        ) : null}

        <div className="field">
          <label>Email</label>
          <input
            type="email"
            value={mode === 'register' ? registerForm.email : loginForm.email}
            onChange={(e) =>
              mode === 'register'
                ? setRegisterForm((s) => ({ ...s, email: e.target.value }))
                : setLoginForm((s) => ({ ...s, email: e.target.value }))
            }
            required
          />
        </div>

        <div className="field">
          <label>Пароль</label>
          <input
            type="password"
            value={mode === 'register' ? registerForm.password : loginForm.password}
            onChange={(e) =>
              mode === 'register'
                ? setRegisterForm((s) => ({ ...s, password: e.target.value }))
                : setLoginForm((s) => ({ ...s, password: e.target.value }))
            }
            required
          />
        </div>

        <button className="btn" disabled={loading} type="submit">
          {loading ? 'Подождите...' : mode === 'login' ? 'Войти' : 'Создать аккаунт'}
        </button>
      </form>

      <p className="muted" style={{ marginTop: 12 }}>
        После успешного входа появится создание/лайки/комментарии через API.
      </p>
    </div>
  );
}

