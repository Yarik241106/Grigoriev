import React, { useEffect, useState } from 'react';
import { apiFetch } from '../api/api';
import PostCard from '../components/PostCard.jsx';
import PostForm from '../components/PostForm.jsx';

export default function ItemsPage({ token }) {
  const [items, setItems] = useState([]);
  const [meta, setMeta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [page, setPage] = useState(1);
  const [limit] = useState(10);
  const [search, setSearch] = useState('');
  const [searchDraft, setSearchDraft] = useState('');

  const fetchItems = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      params.set('page', String(page));
      params.set('limit', String(limit));
      if (search.trim()) params.set('search', search.trim());
      const data = await apiFetch(`/api/items?${params.toString()}`);
      setItems(data.data || []);
      setMeta(data.meta || null);
    } catch (e) {
      setError(e.message || 'Ошибка загрузки');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, search]);

  const applySearch = () => {
    setPage(1);
    setSearch(searchDraft);
  };

  return (
    <div>
      <PostForm token={token} onCreated={fetchItems} />

      <div className="panel" style={{ marginBottom: 16 }}>
        <h2 style={{ marginBottom: 10 }}>Лента</h2>
        <div className="row" style={{ alignItems: 'flex-end' }}>
          <div className="field" style={{ marginBottom: 0 }}>
            <label>Поиск (название/теги)</label>
            <input
              value={searchDraft}
              onChange={(e) => setSearchDraft(e.target.value)}
              placeholder="Например: тест"
            />
          </div>
          <button className="btn" type="button" onClick={applySearch}>
            Найти
          </button>
          <button
            className="linkButton"
            type="button"
            onClick={() => {
              setSearchDraft('');
              setSearch('');
              setPage(1);
            }}
          >
            Сброс
          </button>
        </div>
        {meta ? (
          <div className="muted" style={{ marginTop: 10 }}>
            Страница {meta.page} из {meta.totalPages} • Всего: {meta.total}
          </div>
        ) : null}
      </div>

      {error ? <div className="error">{error}</div> : null}

      {loading ? <div className="muted">Загрузка...</div> : null}

      {items.map((it) => (
        <PostCard key={it.id} item={it} token={token} onRefreshList={fetchItems} />
      ))}

      {meta && !loading ? (
        <div className="panel">
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
            <button className="btn" type="button" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}>
              Назад
            </button>
            <button
              className="btn"
              type="button"
              onClick={() => setPage((p) => Math.min(meta.totalPages || 1, p + 1))}
              disabled={page >= (meta.totalPages || 1)}
            >
              Дальше
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

